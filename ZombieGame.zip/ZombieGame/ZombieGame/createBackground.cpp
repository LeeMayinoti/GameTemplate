#include "pch.h"
#include <SFML/Graphics.hpp>
#include "ZombieGame.h"
#include <iostream>
using namespace std;

template <class T>

 T createBackground(VertexArray& rVA, IntRect stadium)
{
	// Anything we do to rVA we are actually doing to background (in the main function)

	// How big is each tile/texture
	const int TileSize = 50;
	const int TileType = 3;
	const int VertInQuad = 4;

	// memory address of the background valuees
	int* intptr = &TileSize;
	int* intptr = &TileType;

	int worldWidth = stadium.width / TileSize;
	int worldHeight = stadium.height / TileSize;

	// What type of primitive are we using?
	rVA.setPrimitiveType(Quads);

	// Set the size of the vertex array
	rVA.resize(worldWidth * worldHeight * VertInQuad);

	// Start at the beginning of the vertex array
	int currentVertex = 0;

	for (int w = 0; w < worldWidth; w++)
	{
		for (int h = 0; h < worldHeight; h++)
		{
			// Position each vertex in the current quad
			rVA[currentVertex + 0].position = Vector2f(w * TileSize, h * TileSize);
			rVA[currentVertex + 1].position = Vector2f((w * TileSize) + TileSize, h * TileSize);
			rVA[currentVertex + 2].position = Vector2f((w * TileSize) + TileSize, (h * TileSize) + TileSize);
			rVA[currentVertex + 3].position = Vector2f((w * TileSize), (h * TileSize) + TileSize);

			// Define the position in the Texture to draw for current quad
			// Either mud, stone, grass or wall
			if (h == 0 || h == worldHeight - 1 || w == 0 || w == worldWidth - 1)
			{
				// Use the wall texture
				rVA[currentVertex + 0].texCoords = Vector2f(0, 0 + TileType * TileSize);
				rVA[currentVertex + 1].texCoords = Vector2f(TileSize, 0 + TileType * TileSize);
				rVA[currentVertex + 2].texCoords = Vector2f(TileSize, TileSize + TileType * TileSize);
				rVA[currentVertex + 3].texCoords = Vector2f(0, TileSize + TileType * TileSize);
			}
			else
			{
				// Use a random floor texture
				srand((int)time(0) + h * w - h);
				int mOrG = (rand() % TileType);
				int verticalOffset = mOrG * TileSize;

				rVA[currentVertex + 0].texCoords = Vector2f(0, 0 + verticalOffset);
				rVA[currentVertex + 1].texCoords = Vector2f(TileSize, 0 + verticalOffset);
				rVA[currentVertex + 2].texCoords = Vector2f(TileSize, TileSize + verticalOffset);
				rVA[currentVertex + 3].texCoords = Vector2f(0, TileSize + verticalOffset);

			}

			// Position ready for the next for vertices
			currentVertex = currentVertex + VertInQuad;
		}
	}

	return TileSize;
}