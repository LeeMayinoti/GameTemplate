#pragma once
#include "Zombie.h"

using namespace sf;

int createBackground(VertexArray& rVA, IntRect stadium);
Zombie* createHorde(int numZombies, IntRect stadium);
