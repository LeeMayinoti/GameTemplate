#pragma once
#include <SFML/Graphics.hpp>

using namespace sf;

class Player
{
private:
	const float StartSpeed = 200;
	const float StartHealth = 150;

	// Where is the player
	Vector2f Position;

	// Of course we will need a sprite
	Sprite sprite;

	// And a texture
	// !!Watch this space!!
	Texture texture;

	// What is the screen resolution
	Vector2f resolution;

	// What size is the current arena
	IntRect Stadium;

	// How big is each tile of the arena
	int TileSize;

	// Which directions is the player currently moving in
	bool UpPressed;
	bool DownPressed;
	bool LeftPressed;
	bool RightPressed;

	// How much health has the player got?
	int Health;
	// What is the maximum health the player can have
	int MaxHealth;

	// When was the player last hit
	Time LastHit;

	// Speed in pixels per second
	float Speed;


	// All our public functions will come next
public:

	Player();

	// Call this at the end of every game
	void resetPlayerStats();

	void spawn(IntRect arena, Vector2f resolution, int tileSize);

	// Handle the player getting hit by a zombie
	bool hit(Time timeHit);

	// How long ago was the player last hit
	Time getLastHitTime();

	// Where is the player
	FloatRect getPosition();

	// Where is the center of the player
	Vector2f getCenter();

	// Which angle is the player facing
	float getRotation();

	// Send a copy of the sprite to main
	Sprite getSprite();

	// How much health has the player currently got?
	int getHealth();

	// The next four functions move the player
	void moveLeft();

	void moveRight();

	void moveUp();

	void moveDown();

	// Stop the player moving in a specific direction
	void stopLeft();

	void stopRight();

	void stopUp();

	void stopDown();

	// We will call this function once every frame
	void update(float elapsedTime, Vector2i mousePosition);

	// Give player a speed boost
	void upgradeSpeed();

	// Give the player some health
	void upgradeHealth();

	// Increase the maximum amount of health the player can have
	void increaseHealthLevel(int amount);


};