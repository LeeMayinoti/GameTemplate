#pragma once
#include <SFML/Graphics.hpp>

using namespace sf;

class Zombie
{
private:
	// How fast is each zombie type?
	const float BLOATER_SPEED = 40;
	const float CHASER_SPEED = 80;
	const float CRAWLER_SPEED = 20;

	// How tough is each zombie type
	const float BLOATER_HEALTH = 4;
	const float CHASER_HEALTH = 1;
	const float CRAWLER_HEALTH = 2;

	// Make each zombie vary its speed slightly
	const int MaxVarriance = 30;
	const int OFFSET = 101 - MaxVarriance;

	// Where is this zombie?
	Vector2f Position;

	// A sprite for the zombie
	Sprite sprite;

	// How fast can this one run/crawl?
	float speed;

	// How much health has it got?
	float Health;

	// Is it still alive?
	bool Alive;

	// Public prototypes go here	
public:

	// Handle when a bullet hits a zombie
	bool hit();

	// Find out if the zombie is alive
	bool isAlive();

	// Spawn a new zombie
	void spawn(float startX, float startY, int type, int seed);

	// Return a rectangle that is the position in the world
	FloatRect getPosition();

	// Get a copy of the sprite to draw
	Sprite getSprite();

	// Update the zombie each frame
	void update(float elapsedTime, Vector2f playerLocation);
};

