#pragma once
#include <SFML/Graphics.hpp>

using namespace sf;

class Pickup
{
private:
	//Start value for health pickups
	const int HealthStartValue = 60;
	const int AmmoStartValue = 12;
	const int StartWaitTime = 10;
	const int StartSecondsToLive = 8;

	// The sprite that represents this pickup
	Sprite sprite;

	// The arena it exists in
	IntRect Stadium;

	// How much is this pickup worth?
	int Value;

	// What type of pickup is this? 
	// 1 = health, 2 = ammo
	int Type;

	// Handle spawning and disappearing
	bool Spawned;
	float SecondsSinceSpawn;
	float SecondsSinceDeSpawn;
	float SecondsToLive;
	float SecondsToWait;

	// Public prototypes go here
public:

	Pickup(int type);

	// Prepare a new pickup
	void setArena(IntRect stadium);

	void spawn();

	// Check the position of a pickup
	FloatRect getPosition();

	// Get the sprite for drawing
	Sprite getSprite();

	// Let the pickup update itself each frame
	void update(float elapsedTime);

	// Is this pickup currently spawned?
	bool isSpawned();

	// Get the goodness from the pickup
	int gotIt();

	// Upgrade the value of each pickup
	void upgrade();

};



