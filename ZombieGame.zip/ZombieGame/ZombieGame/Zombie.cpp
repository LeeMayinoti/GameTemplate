#include "pch.h"
#include "zombie.h"
#include "TextureHolder.h"
#include <cstdlib>
#include <ctime>

using namespace std;


void Zombie::spawn(float startX, float startY, int type, int seed)
{

	switch (type)
	{
	case 0:
		// Bloater
		sprite = Sprite(TextureHolder::GetTexture(
			"graphics/bloater.png"));

		speed = 40;
		Health = 5;
		break;

	case 1:
		// Chaser
		sprite = Sprite(TextureHolder::GetTexture(
			"graphics/chaser.png"));

		speed = 70;
		Health = 1;
		break;

	case 2:
		// Crawler
		sprite = Sprite(TextureHolder::GetTexture(
			"graphics/crawler.png"));

		speed = 20;
		Health = 3;
		break;
	}

	// Modify the speed to make the zombie unique
	// Every zombie is unique. Create a speed modifier
	srand((int)time(0) * seed);
	// Somewhere between 80 an 100
	float modifier = (rand() % MaxVarriance) + OFFSET;
	// Express as a fraction of 1
	modifier /= 100; // Now equals between .7 and 1
	speed *= modifier;

	Position.x = startX;
	Position.y = startY;

	sprite.setOrigin(25, 25);
	sprite.setPosition(Position);
}

bool Zombie::hit()
{
	Health--;

	if (Health < 0)
	{
		// dead
		Alive = false;
		sprite.setTexture(TextureHolder::GetTexture(
			"graphics/blood.png"));

		return true;
	}

	// injured but not dead yet
	return false;
}

bool Zombie::isAlive()
{
	return Alive;
}

FloatRect Zombie::getPosition()
{
	return sprite.getGlobalBounds();
}


Sprite Zombie::getSprite()
{
	return sprite;
}

void Zombie::update(float elapsedTime,
	Vector2f playerLocation)
{
	float playerX = playerLocation.x;
	float playerY = playerLocation.y;

	// Update the zombie position variables
	if (playerX > Position.x)
	{
		Position.x = Position.x +
			speed * elapsedTime;
	}

	if (playerY > Position.y)
	{
		Position.y = Position.y +
			speed * elapsedTime;
	}

	if (playerX < Position.x)
	{
		Position.x = Position.x -
			speed * elapsedTime;
	}

	if (playerY < Position.y)
	{
		Position.y = Position.y -
			speed * elapsedTime;
	}

	// Move the sprite
	sprite.setPosition(Position);

	// Face the sprite in the correct direction
	float angle = (atan2(playerY - Position.y,
		playerX - Position.x)
		* 180) / 3.141;

	sprite.setRotation(angle);


}