#include "pch.h"
#include "Pickup.h"
#include "TextureHolder.h"

Pickup::Pickup(int type)
{
	// Store the type of this pickup
	Type = type;

	// Associate the texture with the sprite
	if (Type == 1)
	{
		sprite = Sprite(TextureHolder::GetTexture(
			"graphics/health_pickup.png"));

		// How much is pickup worth
		Value = HealthStartValue;

	}
	else
	{
		sprite = Sprite(TextureHolder::GetTexture(
			"graphics/ammo_pickup.png"));

		// How much is pickup worth
		Value = AmmoStartValue;
	}

	sprite.setOrigin(25, 25);

	SecondsToLive = StartSecondsToLive;
	SecondsToWait = StartWaitTime;
}

void Pickup::setArena(IntRect arena)
{

	// Copy the details of the arena to the pickup's m_Arena
	Stadium.left = arena.left + 50;
	Stadium.width = arena.width - 50;
	Stadium.top = arena.top + 50;
	Stadium.height = arena.height - 50;

	spawn();
}

void Pickup::spawn()
{
	// Spawn at a random location
	srand((int)time(0) / Type);
	int x = (rand() % Stadium.width);
	srand((int)time(0) * Type);
	int y = (rand() % Stadium.height);

	// Not currently spawned
	//m_Spawned = false;
	SecondsSinceSpawn = 0;
	Spawned = true;

	sprite.setPosition(x, y);
}

FloatRect Pickup::getPosition()
{
	return sprite.getGlobalBounds();
}

Sprite Pickup::getSprite()
{
	return sprite;
}

bool Pickup::isSpawned()
{
	return Spawned;
}

int Pickup::gotIt()
{
	Spawned = false;
	SecondsSinceDeSpawn = 0;
	return Value;
}

void Pickup::update(float elapsedTime)
{
	if (Spawned)
	{
		SecondsSinceSpawn += elapsedTime;
	}
	else
	{
		SecondsSinceDeSpawn += elapsedTime;
	}


	// Do we need to hide a pickup?
	if (SecondsSinceSpawn > SecondsToLive && Spawned)
	{
		// Revove the pickup and put it somewhere else
		Spawned = false;
		SecondsSinceDeSpawn = 0;
	}

	// Do we need to spawn a pickup
	if (SecondsSinceDeSpawn > SecondsToWait && !Spawned)
	{
		// spawn the pickup and reset the timer
		spawn();
	}

}

void Pickup::upgrade()
{
	if (Type == 1)
	{
		Value += (HealthStartValue * .5);
	}
	else
	{
		Value += (AmmoStartValue * .5);
	}

	// Make them more frequent and last longer
	SecondsToLive += (StartSecondsToLive / 10);
	SecondsToWait -= (StartWaitTime / 10);
}
