#include "pch.h"
#include "bullet.h"


// The constructor
Bullet::Bullet()
{
	BulletShape.setSize(sf::Vector2f(2, 2));
}

void Bullet::shoot(float startX, float startY,
	float targetX, float targetY)
{
	// Keep track of the bullet
	InFlight = true;
	Position.x = startX;
	Position.y = startY;

	// Calculate the gradient of the flight path
	float gradient = (startX - targetX) / (startY - targetY);

	// Any gradient less than zero needs to be negative
	if (gradient < 0)
	{
		gradient *= -1;
	}

	// Calculate the ratio between x and t
	float ratioXY = BulletSpeed / (1 + gradient);

	// Set the "speed" horizontally and vertically
	BulletDistanceY = ratioXY;
	BulletDistanceX = ratioXY * gradient;

	// Point the bullet in the right direction
	if (targetX < startX)
	{
		BulletDistanceX *= -1;
	}

	if (targetY < startY)
	{
		BulletDistanceY *= -1;
	}

	// Finally, assign the results to the
	// member variables
	XTarget = targetX;
	YTarget = targetY;

	// Set a max range of 1000 pixels
	float range = 1000;
	MinX = startX - range;
	MaxX = startX + range;
	MinY = startY - range;
	MaxY = startY + range;

	// Position the bullet ready to be drawn
	BulletShape.setPosition(Position);
}

void Bullet::stop()
{
	InFlight = false;
}

bool Bullet::isInFlight()
{
	return InFlight;
}

FloatRect Bullet::getPosition()
{
	return BulletShape.getGlobalBounds();
}

RectangleShape Bullet::getShape()
{
	return BulletShape;
}


void Bullet::update(float elapsedTime)
{
	// Update the bullet position variables
	Position.x += BulletDistanceX * elapsedTime;
	Position.y += BulletDistanceY * elapsedTime;

	// Move the bullet
	BulletShape.setPosition(Position);

	// Has the bullet gone out of range?
	if (Position.x < MinX || Position.x > MaxX ||
		Position.y < MinY || Position.y > MaxY)
	{
		InFlight = false;
	}

}