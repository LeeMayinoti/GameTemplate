#include "pch.h"
#include "player.h"
#include "TextureHolder.h"

//template <class T> // template class for player 
// 
//void Player(T Speed,T Health,T Maxhealth)
Player::Player()// constructor 
{
	Speed = StartSpeed;
	Health = StartHealth;
	MaxHealth = StartHealth;

	//s = StartSpeed;
	//h = StartHealth;
	//mH = Maxhealth;

	// Associate a texture with the sprite
	// !!Watch this space!!
	sprite = Sprite(TextureHolder::GetTexture(
		"graphics/player.png"));

	// Set the origin of the sprite to the centre, 
	// for smooth rotation
	sprite.setOrigin(25, 25);

	
}

void Player::resetPlayerStats()
{
	Speed = StartSpeed;
	Health = StartHealth;
	MaxHealth = StartHealth;
}

void Player::spawn(IntRect arena, Vector2f resolution, int tileSize)
{
	// Place the player in the middle of the arena
	Position.x = arena.width / 2;
	Position.y = arena.height / 2;

	// Copy the details of the arena to the player's m_Arena
	Stadium.left = arena.left;
	Stadium.width = arena.width;
	Stadium.top = arena.top;
	Stadium.height = arena.height;

	// Remember how big the tiles are in this arena
	TileSize = tileSize;

	// Strore the resolution for future use
	resolution.x = resolution.x;
	resolution.y = resolution.y;

}

Time Player::getLastHitTime()
{
	return LastHit;
}

bool Player::hit(Time timeHit)
{
	if (timeHit.asMilliseconds() - LastHit.asMilliseconds() > 200)// 2 tenths of second
	{
		LastHit = timeHit;
		Health -= 10;
		return true;
	}
	else
	{
		return false;
	}

}

FloatRect Player::getPosition()
{
	return sprite.getGlobalBounds();
}

Vector2f Player::getCenter()// vector 
{
	return Position;
}

float Player::getRotation()
{
	return sprite.getRotation();
}

Sprite Player::getSprite()
{
	return sprite;
}

int Player::getHealth()
{
	return Health;
}

void Player::moveLeft()
{
	LeftPressed = true;
}

void Player::moveRight()
{
	RightPressed = true;
}

void Player::moveUp()
{
	UpPressed = true;
}

void Player::moveDown()
{
	DownPressed = true;
}

void Player::stopLeft()
{
	LeftPressed = false;
}

void Player::stopRight()
{
	RightPressed = false;
}

void Player::stopUp()
{
	UpPressed = false;
}

void Player::stopDown()
{
	DownPressed = false;
}

void Player::update(float elapsedTime, Vector2i mousePosition)
{

	if (UpPressed)
	{
		Position.y -= Speed * elapsedTime;
	}

	if (DownPressed)
	{
		Position.y += Speed * elapsedTime;
	}

	if (RightPressed)
	{
		Position.x += Speed * elapsedTime;
	}

	if (LeftPressed)
	{
		Position.x -= Speed * elapsedTime;
	}

	sprite.setPosition(Position);



	// Keep the player in the arena
	if (Position.x > Stadium.width - TileSize)
	{
		Position.x = Stadium.width - TileSize;
	}

	if (Position.x < Stadium.left + TileSize)
	{
		Position.x = Stadium.left + TileSize;
	}

	if (Position.y > Stadium.height - TileSize)
	{
		Position.y = Stadium.height - TileSize;
	}

	if (Position.y < Stadium.top + TileSize)
	{
		Position.y = Stadium.top + TileSize;
	}

	// Calculate the angle the player is facing
	float angle = (atan2(mousePosition.y - resolution.y / 2,
		mousePosition.x - resolution.x / 2)
		* 180) / 3.141;

	sprite.setRotation(angle);
}

void Player::upgradeSpeed()
{
	// 20% speed upgrade
	Speed += (StartSpeed * .2);
}

void Player::upgradeHealth()
{
	// 20% max health upgrade
	MaxHealth += (StartHealth * .2);

}

void Player::increaseHealthLevel(int amount)
{
	Health += amount;

	// But not beyond the maximum
	if (Health > MaxHealth)
	{
		Health = MaxHealth;
	}
}